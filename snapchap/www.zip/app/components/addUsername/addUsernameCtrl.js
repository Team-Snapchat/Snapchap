angular.module('snapchat').controller('addUsernameCtrl', function ($scope, $stateParams, mainService) {

  mainService.hideMenu();
  
});
