angular.module('snapchat').controller('logInSignUpCtrl', function ($scope, $stateParams, mainService) {

  mainService.hideMenu();

});
