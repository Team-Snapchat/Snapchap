angular.module('snapchat').controller('sendToCtrl', function ($scope, $stateParams) {


});
