angular.module('snapchat').controller('watchMessagesCtrl', function ($scope, $stateParams, mainService) {

  mainService.hideMenu();
  
});
