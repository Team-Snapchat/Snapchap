angular.module('snapchat').controller('emailCtrl', function ($scope, $stateParams, mainService) {

  mainService.hideMenu();
  
});
