angular.module('snapchat').controller('navCtrl', function ($scope, $stateParams, mainService) {

  mainService.showMenu();

  
});
