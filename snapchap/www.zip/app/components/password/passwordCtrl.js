angular.module('snapchat').controller('passwordCtrl', function ($scope, $stateParams, mainService) {

  mainService.hideMenu();
  
});
