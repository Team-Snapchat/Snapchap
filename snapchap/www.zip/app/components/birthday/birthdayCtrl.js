angular.module('snapchat').controller('birthdayCtrl', function ($scope, $stateParams) {


});
