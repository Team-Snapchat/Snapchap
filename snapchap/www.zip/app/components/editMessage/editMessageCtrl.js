angular.module('snapchat').controller('editMessageCtrl', function ($scope, $stateParams, mainService) {

  mainService.hideMenu();
  
});
