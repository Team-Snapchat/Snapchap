angular.module('snapchat').service('tempService', function() {

this.createUser = {
  
}
});
