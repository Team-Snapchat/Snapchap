angular.module('snapchat').service('tempService', function() {


});
